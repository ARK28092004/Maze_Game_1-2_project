# include "iGraphics.h"
#include <iostream>
#include <cstdlib>
#include<vector>
#include<algorithm>
#include<windows.h>
#include<time.h>
#include<MMsystem.h>
#include <stdio.h>
#include <stdlib.h>
#pragma comment(lib,"winmm.lib")
#define pb push_back
#define ll unsigned long long int
#define randnum(min, max) \
        ((rand() % (int)(((max) + 1) - (min))) + (min))
#define pb push_back
#define FR2SQ(f,r) (21+f)+(r*10)
using namespace std;
char str[100], str2[100],cntt=-1;
int hmm=0,fstx=10,fsty=680,ax=123,ay=663;
int x=98,y,len,brd_sq_num=120,cur_piece,cur_state1,cur_state2,total_move,mov_piece[32],white_ki_chk=0,black_ki_chk=0,white_ki_pos,black_ki_pos;
int knDir[8]={-8,-19,-21,-12,8,19,21,12},exi=0;
int rkDir[4]={-1,-10,1,10};
int biDir[4]={-9,-11,11,9};
int quDir[8]={-1,-10,1,10,-9,-11,11,9};
int kiDir[8]={-11,-10,-9,-1,1,9,10,11};
int piece[32];
int pieceknight[13],pieceki[13],piecerqu[13],piecebq[13];
#define pop(b) PopBit(b)
#define count countBit(b)
int w_b=1,w_k=2,w_q=3,w_ki=4,w_p=5;

struct S_board{
    int pieces[120],pList[13][10];
    ll pawns[3],pos_ke,py;
    int king_square[2],side,ply,fifty_move,his_ply,piece_num[13],bigPce[3],majPce[3],minPce[3];
};
struct stat_to_co{
    int x_co,y_co;
}
stat_to_co[120];
int sq120to64[120],sq64to120[64],last;
extern int sq120to64[120],sq64to120[64];
int col[64],time1=0;
enum {File_A,File_B,File_C,File_D,File_E,File_F,File_G,File_H};
enum {Empty,w_pa,w_kn,w_bi,w_ro,w_qu,w_kin,b_pa,b_kn,b_bi,b_ro,b_qu,b_kin};
enum {rank_1,rank_2,rank_3,rank_4,rank_5,rank_6,rank_7,rank_8};
enum {White,Black,Both};
enum {A1=21,B1,C1,D1,E1,F1,G1,H1,
      A2=31,B2,C2,D2,E2,F2,G2,H2,
      A3=41,B3,C3,D3,E3,F3,G3,H3,
      A4=51,B4,C4,D4,E4,F4,G4,H4,
      A5=61,B5,C5,D5,E5,F5,G5,H5,
      A6=71,B6,C6,D6,E6,F6,G6,H6,
      A7=81,B7,C7,D7,E7,F7,G7,H7,
      A8=91,B8,C8,D8,E8,F8,G8,H8,No_sq
};
int box[64];
char bo[10][20]={"bomb\\1.bmp","bomb\\2.bmp","bomb\\3.bmp"};
char im[10][20]={"images\\1.bmp","images\\2.bmp","images\\3.bmp"};
char bl[15][20]={"images\\b_b.bmp","images\\b_k.bmp","images\\b_ki.bmp","images\\b_p.bmp","images\\b_q.bmp","images\\b_r.bmp"};
char wh[15][20]={"images\\w_b.bmp","images\\w_k.bmp","images\\w_ki.bmp","images\\w_p.bmp","images\\w_q.bmp","images\\w_r.bmp"};
char win[10][30]={"images\\white_win.bmp","images\\Black_win.bmp","images\\white.bmp","images\\black.bmp"};
int st = 1,a,b,state;
int pos[120],p1=-1,wi=0;
int timer[10];
int bom21=-1;
struct clock {
    int time_left;
    char minute[5];
    char strSecond[6];
} blackClock, whiteClock;
vector<string> moves;
char* itoa2(int num,char str[])
{
    vector<char>v;
    int len=0,num1=num;
    while(num)
    {

        len++,v.pb(num%10+'0'),num/=10;
    }
    reverse(v.begin(),v.end());
    //cout<<num1<< " "<<len<<"\n";
    for(int i=0;i<len;i++)str[i]=v[i];
    str[len]='\0';
    return str;
}
void drawBoard()
{
	iSetColor(150, 150, 150);
	int p2,width=64;
	for(int i=0;i<8;i++)
    {
        for(int j=0;j<8;j++)
        {
            if((i+j)%2==0)
            {
                iSetColor(0,0,139);
            }
            else iSetColor(173,216,230);
            p2=i*8+j;
            if(p2==56)iSetColor(255,0,0);
            if(p2==7)iSetColor(255,255,255);
            iFilledRectangle(98+width*i,142+width*j,width,width);
        }
    }
}
int lx=1;
const int bitTable[64]={63,30,3,32,25,41,22,33,15,50,42,13,11,53,19,34,61,29,2,51,21,43,45,10,18,47,1,54,9,57,0,
35,62,31,40,4,49,5,52,26,60,6,23,44,46,27,56,16,7,39,48,24,59,14,12,55,38,28,58,
20,37,17,36,8
};
int PopBit(ll *bb)
{
    ll  b=*bb ^(*bb-1);
    unsigned int fold=(unsigned) ((b& 0xffffffff)^(b<<32));
    *bb &=(*bb-1);
    return bitTable[(fold * 0x783a9b23)>>26];
}
ll countBit(ll b)
{
    int r;
    for(r=0;b;b&=(b-1))r++;
    return r;
}
void move_piece()
{

}
void initsq120to64()
{
    int index=0,file=File_A,rank1=rank_1,sq=A1,sq64=0;
    for(;index<brd_sq_num;index++)
    {
        sq120to64[index]=65;
    }
    for(index=0;index<64;index++)sq64to120[index]=120;
    for(rank1=rank_1;rank1<=rank_8;rank1++)
    {
        for(file=File_A;file<=File_H;file++)
        {
            sq=(FR2SQ(file,rank1));
            sq64to120[sq64]=sq;
            sq120to64[sq]=sq64,sq64++;
        }
    }
}
/*
	function iDraw() is called again and again by the system.
*/
void ShowBomb()
{
    int p=randnum(0,63),sta=sq64to120[p],x=stat_to_co[sta].x_co,y=stat_to_co[sta].y_co,bom2=randnum(0,63);
    for(int i=0;i<64;i++)box[i]=0;
    box[p]=1,box[bom2]=1,bom21=bom2;
    p1=p;
}
int tim=0;
void Show()
{
    if(p1>=0 && p1!=63){
                int q1=sq64to120[p1],xx1=stat_to_co[q1].x_co,yy1=stat_to_co[q1].y_co;
                box[p1]=1;
                for(int j=0;j<3;j++)
                iShowBMP2(xx1,yy1,bo[j],255);
            }
            if(bom21>=0 && bom21!=63){
                int q1=sq64to120[bom21],xx1=stat_to_co[q1].x_co,yy1=stat_to_co[q1].y_co;
                box[bom21]=1;
                for(int j=0;j<3;j++)
                iShowBMP2(xx1,yy1,bo[j],255);
            }
}
void iDraw()
{
	//place your drawing codes here
	iClear();
	//iShowBMP(50,100,im[1]);
    if(1){
        if(wi==0)
        drawBoard();
        int q1=sq64to120[last],xx1=stat_to_co[q1].x_co,yy1=stat_to_co[q1].y_co;
        if(wi==0) Show();
        if(wi==0)
        iShowBMP2(xx1,yy1,"images\\toy.bmp",255);
        if(wi==0 && last==63)
        {
            wi=1;
            iShowBMP2(220,420,"images\\win.bmp",255);
        }
        if(wi==01 && last==63)
        {
            wi=1;
            iShowBMP2(220,420,"images\\win.bmp",255);
        }
        if(w_p==5)
        {
            timer[0]=iSetTimer(1000,ShowBomb);
            w_p=6;
        }
        if(wi==-1)
        {
            iShowBMP(220,290,"bomb\\lo.bmp");
        }

        if((bom21==last|| p1==last) && wi==0)
        {
            wi=-1;
            iShowBMP(220,240,"bomb\\lo.bmp");
        }
    }
}
/*
	function iMouseMove() is called when the user presses and drags the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
void iMouseMove(int mx, int my)
{
	//place your codes here

	//printf("%d %d\n",mx,my);
}

/*
	function iMouse() is called when the user presses/releases the mouse.
	(mx, my) is the position where the mouse pointer is.
*/
int stat(int mx,int my)
{
    int cnt=0,cnt2=1;
	for(int i=98;i<=mx;i+=64)
    {
        cnt++;
    }
    for(int j=654;j>=my;j-=64)
    {
        cnt2++;
    }
    state=cnt2*10+cnt;
}
void pus(int piec,int bx1,int bx2)
{

}
void iMouse(int button, int state, int mx, int my)
{

}
void iPassiveMouseMove(int mx, int my)
{

}

/*
	function iKeyboard() is called whenever the user hits a key in keyboard.
	key- holds the ASCII value of the key pressed.
*/
int mode;
void iKeyboard(unsigned char key)
{
	int i;
	if(st==-2)
	{
        if(key == '\r')
		{
			mode = 0;
			strcpy(str2, str);
			printf("%s\n", str2);
			for(i = 0; i < len; i++)
				str[i] = 0;
			len = 0;
		}
		else
		{
			str[len] = key;
			len++;
		}
	}

	if(key == 'x')
	{
		//do something with 'x'
		exit(0);
	}
	//place your codes for other keys here
}

/*
	function iSpecialKeyboard() is called whenver user hits special keys like-
	function keys, home, end, pg up, pg down, arraows etc. you have to use
	appropriate constants to detect them. A list is:
	GLUT_KEY_F1, GLUT_KEY_F2, GLUT_KEY_F3, GLUT_KEY_F4, GLUT_KEY_F5, GLUT_KEY_F6,
	GLUT_KEY_F7, GLUT_KEY_F8, GLUT_KEY_F9, GLUT_KEY_F10, GLUT_KEY_F11, GLUT_KEY_F12,
	GLUT_KEY_LEFT, GLUT_KEY_UP, GLUT_KEY_RIGHT, GLUT_KEY_DOWN, GLUT_KEY_PAGE UP,
	GLUT_KEY_PAGE DOWN, GLUT_KEY_HOME, GLUT_KEY_END, GLUT_KEY_INSERT
*/
void iSpecialKeyboard(unsigned char key)
{

    if(wi==1)return;
	if(key == GLUT_KEY_UP)
	{
		if(last>7)last-=8;
		else wi=-1;
	}
	else{
        if(key==GLUT_KEY_DOWN)
        {
            if(last<64-8)last+=8;
            else wi=-1;
        }
        else if(key==GLUT_KEY_RIGHT)
        {
            if(last%8!=7)last++;
            else wi=-1;
        }
        else if(key==GLUT_KEY_LEFT)
        {
            if(last%8)last--;
            else wi=-1;
        }
	}

	//place your codes for other keys here
}
int main()
{
	//place your own initialization codes here.
	initsq120to64();
	initsq120to64();
	int y1=152,x1=108;
	for(int ind=0;ind<64;ind++)
    {
        int p=sq64to120[ind];
        int x2=x1+((ind)%8)*64,y2=(y1+(7-(ind)/8)*64);
        stat_to_co[p].x_co=x2,
        stat_to_co[p].y_co=y2;
    }
	len = 0;
	mode = 0;
	str[0]= 0;
	iInitialize(700,700, "ChessBotCom");
	return 0;
}

